import 'package:recce/configs/app_urls.dart';
import 'package:recce/data/network/network_api_services.dart';
import 'package:recce/models/user_model.dart';

class LoginRepository {
  final _api = NetworkServicesApi();

  //login method
  Future<UserModel> loginApi(dynamic data) async {
    final response = await _api.postApi(AppUrls.loginapi, data);
    print('Response from login API: $response $data');
    
    try {
      // Print the response to verify its structure
      print('Response JSON: $response');
      
      // Deserialize JSON to UserModel
      UserModel userModel = UserModel.fromJson(response);
      
      // Print the UserModel to verify deserialization
      print('Deserialized UserModel: $userModel');
      
      return userModel;
    } catch (e) {
      print('Error parsing UserModel: $e');
      rethrow; // rethrow the error after logging it
    }
  }
}
