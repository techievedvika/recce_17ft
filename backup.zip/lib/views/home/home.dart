
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geolocator/geolocator.dart';
import 'package:recce/components/custom_appbar.dart';
import 'package:recce/components/custom_drawer.dart';
import 'package:recce/configs/routes/routes_name.dart';
import 'package:recce/blocs/form_cubit.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      // create: (context) => FormCubit()..loadForm(),
        create: (context){
           Future.delayed(const Duration(microseconds: 300));
           return FormCubit()..loadForm();
        
        },
      child: Scaffold(
        appBar: const CustomAppbar(title: 'Home Screen'),
       
        body: BlocConsumer<FormCubit, FormStates>(
          listener: (context, state) {
            if (state is FormSubmitted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Form submitted: ${state.formData.message}'),
                ),
              );
              Navigator.pushNamed(context, RoutesName.homeScreen);
            } else if (state is FormError) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Error: ${state.message}')),
              );
            } else if (state is CurrentLocation) {
            
            }
          },
          builder: (context, state) {
            if (state is FormLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is FormLoaded) {
              return ListViewWidget(formJsonList: state.formData,currentPosition: state.position,);
            } else if (state is FormError) {
              return Center(child: Text(state.message));
            }
            return const Center(child: Text('Please wait...'));
          },
        ),
         floatingActionButton: FloatingActionButton(
        onPressed: () => context.read<FormCubit>().loadForm(),
        child: const Icon(Icons.refresh),
      ),
      ),
    );
  }
}
class ListViewWidget extends StatelessWidget {
  final List<Map<String, dynamic>> formJsonList;
  final Position? currentPosition;

  const ListViewWidget({
    super.key,
    required this.formJsonList,
    required this.currentPosition,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView.builder(
        itemCount: formJsonList.length,
        itemBuilder: (context, index) {
          final formItem = formJsonList[index];
          final formName = formItem['name'] as String;
          final collectionJson = formItem['collection'] as Map<String, dynamic>;

          return Card(
            elevation: 4,
            margin: const EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              title: Text(
                formName,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: const Text('no Description'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/form1_screen',
                  arguments: {
                    'formName': formName,
                    'collectionJson': collectionJson,
                    'position':currentPosition,
                  },
                );
              },
            ),
          );
        },
      ),
    );
  }
}
