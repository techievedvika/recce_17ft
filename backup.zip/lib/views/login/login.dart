import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart'; // Import SharedPreferences
import 'package:recce/blocs/login_bloc.dart';
import 'package:recce/components/curved_container.dart';
import 'package:recce/components/custom_button.dart';
import 'package:recce/components/custom_textfield.dart';
import 'package:recce/configs/color/color.dart';
import 'package:recce/configs/helper/responsive_helper.dart';
import 'package:recce/utils/enums.dart';
import '../../configs/routes/routes_name.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  late TextEditingController usernameController;
  late TextEditingController passwordController;
  final GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();
  bool passwordVisible = false;

  @override
  void initState() {
    super.initState();
    usernameController = TextEditingController();
    passwordController = TextEditingController();
    _checkLoginState(); // Check login state on init
  }

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  // Check login state on app start
  Future<void> _checkLoginState() async {
    final prefs = await SharedPreferences.getInstance();
    final isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
    if (isLoggedIn) {
      // Navigate to home screen if already logged in
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacementNamed(context, RoutesName.homeScreen);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final responsive = Responsive(context);

    return Scaffold(
      backgroundColor: AppColors.onPrimary,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const CurvedContainer(),
            Image.asset(
              'assets/logo.png',
              height: responsive.responsiveValue(
                  small: 60.0, medium: 80.0, large: 100.0),
              width: responsive.responsiveValue(
                  small: 150.0, medium: 200.0, large: 250.0),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 40, top: 0),
              child: Align(
                alignment: Alignment.topLeft,
                child: Text(
                  'Login',
                  style: AppStyles.heading1(context, AppColors.onBackground),
                ),
              ),
            ),
            SizedBox(height: responsive.responsiveValue(
                small: 20.0, medium: 30.0, large: 40.0),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Form(
                key: loginFormKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    CustomTextFormField(
                      textController: usernameController,
                      textInputType: TextInputType.text,
                      prefixIcon: Icons.phone,
                      hintText: 'Username',
                      labelText: 'Enter your username',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your username';
                        }
                        return null;
                      },
                      onChanged: (value) {
                        context
                            .read<LoginBloc>()
                            .add(UsernameChanged(username: value!));
                        return null;
                      },
                    ),
                    SizedBox(
                      height: responsive.responsiveValue(
                          small: 30.0, medium: 40.0, large: 20.0),
                    ),
                    CustomTextFormField(
                      textController: passwordController,
                      obscureText: passwordVisible,
                      prefixIcon: Icons.password,
                      hintText: 'Password',
                      labelText: 'Enter your password',
                      suffixIcon: IconButton(
                        icon: Icon(passwordVisible
                            ? Icons.visibility_off
                            : Icons.visibility),
                        onPressed: () {
                          setState(() {
                            passwordVisible = !passwordVisible;
                          });
                        },
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your password';
                        }
                        return null;
                      },
                      onChanged: (value) {
                        context
                            .read<LoginBloc>()
                            .add(PasswordChanged(password: value!));
                        return null;
                      },
                    ),
                    SizedBox(
                      height: responsive.responsiveValue(
                          small: 20.0, medium: 30.0, large: 20.0),
                    ),
                    CustomButton(
                      title: 'Login',
                      onPressedButton: () {
                        if (loginFormKey.currentState!.validate()) {
                          context.read<LoginBloc>().add(LoginButtonPressed());
                        }
                        
                      },
                    ),
                    BlocBuilder<LoginBloc, LoginState>(
                      builder: (context, state) {
                        if (state.postApiStatus == PostApiStatus.loading) {
                          return const Center(
                              child: CircularProgressIndicator());
                        } else if (state.postApiStatus ==
                            PostApiStatus.success) {
                          _saveLoginState(); // Save login state
                          WidgetsBinding.instance.addPostFrameCallback((_) {
                            Navigator.pushReplacementNamed(
                                context, RoutesName.homeScreen);
                          });
                        } else if (state.postApiStatus == PostApiStatus.error) {
                          return Center(
                              child: Text('Login failed: ${state.message}'));
                        }
                        return const SizedBox.shrink();
                      },
                    ),
                    SizedBox(
                      height: responsive.responsiveValue(
                          small: 10.0, medium: 20.0, large: 30.0),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Save login state
  Future<void> _saveLoginState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isLoggedIn', true);
  }
}
