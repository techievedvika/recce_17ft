//this view.dart files know as barrer files which are used to manage the clean code files

export 'home/home.dart';
export 'login/login.dart';
export 'splash/splash.dart';
