part of 'login_bloc.dart';

class LoginState extends Equatable {
  const LoginState({
    this.username = '',
    this.password = '',
    this.message = '',
    this.status = '',
    this.postApiStatus = PostApiStatus.initial,
  });

  final String username;
  final String password;
  final String message;
  final String status;
  final PostApiStatus postApiStatus;

  LoginState copyWith({
    String? username,
    String? password,
    String? message,
    String? status,
    PostApiStatus? postApiStatus,
  }) {
    return LoginState(
      username: username ?? this.username,
      password: password ?? this.password,
      message: message ?? this.message,
      status: status ?? this.status,
      postApiStatus: postApiStatus ?? this.postApiStatus,
    );
  }

  @override
  List<Object> get props =>
      [username, password, message, status, postApiStatus];
}
