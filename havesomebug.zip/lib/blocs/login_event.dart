part of 'login_bloc.dart';

abstract class LoginEvents extends Equatable{
  const LoginEvents();

@override
List<Object> get props => [];
  
}

class UsernameChanged extends LoginEvents{
  const UsernameChanged({required this.username});
  final String username;
  @override
  List<Object> get props => [username];
  
}


class PasswordChanged extends LoginEvents{
  const PasswordChanged({required this.password});
  final String password;
  @override
  List<Object> get props => [password];


}

class EmailUnFocused extends LoginEvents{

}

class PasswordUnfocused extends LoginEvents{

}

class LoginButtonPressed extends LoginEvents{

}